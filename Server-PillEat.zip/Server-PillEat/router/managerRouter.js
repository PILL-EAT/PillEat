const express = require('express');
var router = express.Router()

var manager = require('../lib/manager');

// 사용자 정보 목록 요청
router.get('/user-list', (req, res) => {
    manager.userList(req, res);
});

// 검색 약 추가 
router.get('/drug/add', (req, res) => {
    manager.addDrug(req, res);
});

module.exports = router;