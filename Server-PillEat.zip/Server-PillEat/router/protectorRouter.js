const express = require('express');
var router = express.Router()

var protector = require('../lib/protector');

// 복용자 약 복용 완료 여부 요청
router.get('/drug/finishyn/:takerId', (req, res) => {
    protector.finishYN(req, res);
});

// 복용자 복용 시간 알림 
router.get('/drug/alert/:takerId', (req, res) => {
    protector.alert(req, res);
});

// 복용자 입력 요청
router.post('/input-taker', (req, res) => {
    protector.inputTaker(req, res);
});




module.exports = router;